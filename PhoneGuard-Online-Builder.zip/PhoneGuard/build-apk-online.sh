#!/usr/bin/env bash
set -e
curl -fsSL https://services.gradle.org/distributions/gradle-8.9-bin.zip -o /tmp/gradle.zip
rm -rf /tmp/gradle-8.9
unzip -q /tmp/gradle.zip -d /tmp
gradle_bin=/tmp/gradle-8.9/bin/gradle
"$gradle_bin" assembleDebug
