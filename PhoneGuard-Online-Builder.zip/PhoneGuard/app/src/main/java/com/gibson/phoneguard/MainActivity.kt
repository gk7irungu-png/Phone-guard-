package com.gibson.phoneguard

import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun showDashboard() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        val title = TextView(this).apply { text = "Phone Guard"; textSize = 30f }
        val status = TextView(this).apply { text = "\nProtection dashboard\n"; textSize = 18f }
        val keyButton = Button(this).apply { text = "Security Key" }
        val checks = Button(this).apply { text = "Run Device Checks" }
        val about = TextView(this).apply { text = "\nPhone Guard provides local security settings and checks. It does not secretly monitor, control, or transmit your phone data." }
        root.addView(title); root.addView(status); root.addView(checks); root.addView(keyButton); root.addView(about)
        setContentView(root)
        checks.setOnClickListener { runChecks(status) }
        keyButton.setOnClickListener { if (unlocked) changeKey() else unlock() }
    }

    private fun currentKey(): String = prefs.getString("key", "GUARD-2026")!!

    private fun unlock() {
        val input = EditText(this).apply { hint = "Security key" }
        AlertDialogBuilder(this, "Unlock", input, "Verify") { if (input.text.toString() == currentKey()) { unlocked = true; Toast.makeText(this,"Unlocked",Toast.LENGTH_SHORT).show() } else Toast.makeText(this,"Incorrect key",Toast.LENGTH_SHORT).show() }
    }

    private fun changeKey() {
        val input = EditText(this).apply { hint = "New security key" }
        AlertDialogBuilder(this, "Change Security Key", input, "Save") { val k=input.text.toString().trim(); if(k.length>=6){prefs.edit().putString("key",k).apply(); unlocked=false; Toast.makeText(this,"Key changed",Toast.LENGTH_SHORT).show()} else Toast.makeText(this,"Use at least 6 characters",Toast.LENGTH_SHORT).show() }
    }

    private fun runChecks(status: TextView) {
        val adb = Settings.Global.getString(contentResolver, Settings.Global.ADB_ENABLED) == "1"
        status.text = "\nChecks complete\n\nUSB debugging: ${if(adb) "ON — review if you don't need it" else "OFF"}\nSecurity key: configured\nNetwork: local app only"
    }
}

private fun AlertDialogBuilder(activity: AppCompatActivity, title:String, input:EditText, positive:String, action:()->Unit) {
    androidx.appcompat.app.AlertDialog.Builder(activity).setTitle(title).setView(input).setNegativeButton("Cancel",null).setPositiveButton(positive){_,_->action()}.show()
}
